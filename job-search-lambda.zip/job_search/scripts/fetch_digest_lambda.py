#!/usr/bin/env python3
"""
fetch_digest.py for Lambda - Fetch Gmail messages from the last 24 hours
Reads credentials from the Lambda package (job_search/secrets/)
"""

import json
import sys
import urllib.request
import urllib.parse
from datetime import datetime, timedelta, timezone
from pathlib import Path
import os

def get_creds_path():
    """Get path to credentials in Lambda or local."""
    # Try Lambda path first
    lambda_path = Path("/var/task/job_search/secrets/gmail_oauth.json")
    if lambda_path.exists():
        return lambda_path
    
    # Fall back to local path
    local_path = Path.home() / '.openclaw' / 'workspace' / 'secrets' / 'gmail_oauth.json'
    if local_path.exists():
        return local_path
    
    return None

def load_or_refresh_token():
    """Load cached credentials and refresh access token if needed."""
    creds_path = get_creds_path()
    if not creds_path:
        print(f"❌ ERROR: Gmail credentials not found", file=sys.stderr)
        return None
    
    with open(creds_path) as f:
        creds = json.load(f)
    
    # Refresh the access token
    data = urllib.parse.urlencode({
        "client_id": creds["client_id"],
        "client_secret": creds["client_secret"],
        "refresh_token": creds["refresh_token"],
        "grant_type": "refresh_token"
    }).encode()
    
    req = urllib.request.Request("https://oauth2.googleapis.com/token", data=data, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    
    try:
        with urllib.request.urlopen(req) as resp:
            response = json.loads(resp.read())
            if "access_token" not in response:
                print(f"❌ ERROR: No access_token in response: {response}", file=sys.stderr)
                return None
            return response["access_token"]
    except urllib.error.HTTPError as e:
        body = e.read().decode() if hasattr(e, 'read') else str(e)
        print(f"❌ ERROR: Failed to refresh token: {e.code if hasattr(e, 'code') else 'unknown'}", file=sys.stderr)
        return None

def gmail_get(path, token):
    """Make authenticated request to Gmail API."""
    url = f"https://gmail.googleapis.com/gmail/v1/{path}"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

def header_val(headers, name):
    """Extract header value by name (case-insensitive)."""
    for h in headers:
        if h["name"].lower() == name.lower():
            return h["value"]
    return ""

def fetch_emails():
    """Fetch emails from last 24 hours."""
    # Get access token (refresh if needed)
    token = load_or_refresh_token()
    if not token:
        return []
    
    # Search for messages from last 24 hours
    since = int((datetime.now(timezone.utc) - timedelta(hours=24)).timestamp())
    query = f"after:{since}"
    encoded_query = urllib.parse.urlencode({"q": query, "maxResults": 50})

    try:
        result = gmail_get(f"users/me/messages?{encoded_query}", token)
        messages = result.get("messages", [])

        emails = []
        for msg in messages:
            detail = gmail_get(
                f"users/me/messages/{msg['id']}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date",
                token
            )
            headers = detail.get("payload", {}).get("headers", [])
            emails.append({
                "subject": header_val(headers, "Subject") or "(no subject)",
                "from": header_val(headers, "From"),
                "date": header_val(headers, "Date"),
                "snippet": detail.get("snippet", "")
            })

        return emails
    
    except urllib.error.HTTPError as e:
        print(f"❌ ERROR: Gmail API error: {e.code if hasattr(e, 'code') else 'unknown'}", file=sys.stderr)
        return []

if __name__ == "__main__":
    emails = fetch_emails()
    print(json.dumps(emails, indent=2))
