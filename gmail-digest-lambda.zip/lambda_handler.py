"""
Gmail Digest Lambda - Entry point
Fetches emails and sends summary
"""

import sys
import json
import os
from datetime import datetime

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gmail_digest.scripts import fetch_digest

def lambda_handler(event, context):
    """Main Lambda handler for gmail digest."""
    try:
        print("Starting Gmail digest Lambda function...")
        
        # Fetch emails
        print("Fetching emails from the last 24 hours...")
        emails = fetch_digest.fetch_emails()
        
        print(f"Found {len(emails)} emails")
        
        # Format summary
        if emails:
            summary = format_email_summary(emails)
            print("\n" + summary)
        else:
            print("No emails found in the last 24 hours")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Gmail digest completed',
                'emails_found': len(emails),
                'timestamp': datetime.utcnow().isoformat()
            })
        }
        
    except Exception as e:
        print(f"Error in lambda_handler: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Gmail digest failed'
            })
        }

def format_email_summary(emails):
    """Format emails into a readable summary."""
    summary = "📧 Your Gmail Digest (Last 24 Hours)\n"
    summary += "=" * 50 + "\n\n"
    
    for i, email in enumerate(emails, 1):
        summary += f"{i}. {email.get('subject', '(no subject)')}\n"
        summary += f"   From: {email.get('from', 'Unknown')}\n"
        summary += f"   Date: {email.get('date', 'Unknown')}\n"
        if email.get('snippet'):
            snippet = email['snippet'][:100] + "..." if len(email['snippet']) > 100 else email['snippet']
            summary += f"   Preview: {snippet}\n"
        summary += "\n"
    
    return summary
