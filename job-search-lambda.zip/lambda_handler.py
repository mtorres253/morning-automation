"""
Job Search Lambda - Entry point
Runs job search digest only
"""

import sys
import json
import os

# Add current directory to path so imports work
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from job_search.scripts import search_jobs, filter_and_deliver

def lambda_handler(event, context):
    """Main Lambda handler for job search digest."""
    try:
        print("Starting job search Lambda function...")
        
        # Run job search
        print("Searching for jobs...")
        search_jobs.main()
        
        # Filter and deliver
        print("Filtering and delivering results...")
        filter_and_deliver.main()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Job search completed successfully',
                'timestamp': str(os.popen('date').read()).strip()
            })
        }
        
    except Exception as e:
        print(f"Error in lambda_handler: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Job search failed'
            })
        }
